<!--Sizes :- Used for onscreen indication of the currently active breakpont-->
  <sizes onclick='onClickMenu();'>
    <div id="exsmall">ExSmall: - Phone</div>
    <div id="small"> Small: - phone - landscape</div>
    <div id="medium"> Medium: - Tablet Portrait</div>
    <div id="large"> Large (Tablet: - Landscape) </div>
    <div id="larger">Larger: - Desktop standard</div>
    <div id="exlarge">exLarge: - Desktop large</div>
    <div id="massive"> Massive: - Desktop Massive</div>
    <div id="vast"> Vast: - Desktop Maxium possible</div>
  </sizes>
