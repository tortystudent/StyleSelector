//alert("loaded ok");
// $('.dropdown-toggle').dropdown()
$('.collapse').collapse('show')
$('#myModal').modal('hide')
//$('.typeahead').typeahead()
$('.tabs').button()
$('.tip').tooltip()
$(".alert-message").alert()
var  menu_open=false;



function onClickMenu() {
        //if (parseInt(jQuery('.body').css('left')) >= 80) {
  if(menu_open==false){
          openMenu();
        }else{
          closeMenu();
        }
      }

      function onClickCover() {
        closeMenu();
      }
      var scrollPos;

      function openMenu() {
        scrollPos = jQuery('body').scrollTop();
        jQuery('.wrapper').animate({
          left: '80%'
        });
        jQuery('.mobile-menu-bar').animate({
          left: '80%'
        });
        jQuery('.off-screen-left').css('display', 'block');
        jQuery('body').css({
          position: 'fixed',
          top: -(document.body.scrollTop)
        });
        jQuery('html').css({
          position: 'fixed',
          top: -(document.body.scrollTop)
        });
        jQuery(".body").on("touchmove", false);
        jQuery('.cover').fadeIn();
          menu_open=true;
      }

      function closeMenu() {
        jQuery('.wrapper').animate({
          left: '0%'
        });
        jQuery('.mobile-menu-bar').animate({
          left: '0%'
        }, function() {
          jQuery('.off-screen-left').css('display', 'none');
        });
        jQuery('body').css({
          position: 'inherit'
        });
        jQuery('html').css({
          position: 'inherit'
        });
        jQuery('body').scrollTop(scrollPos);
        jQuery(".body").off("touchmove", false);
        jQuery('.cover').fadeOut();
           menu_open=false;
      }
      jQuery(document).ready(function() {
        //init parralax
        //var skr = skrollr.init();
        //animate pointer
        /*var OFFSET_CONST = 30;
        var originalLeft = jQuery('nav ul .current').position().left + OFFSET_CONST;
        jQuery('.pointer').animate({left: originalLeft}, 500,'easeOutCubic');
        jQuery('nav .nav li').mouseover(function() {
        //stop current animation
        jQuery('.pointer').stop(true,false);
        var left = jQuery(this).position().left + OFFSET_CONST;
        jQuery('.pointer').animate({left: left}, 500,'easeOutCubic');
        });
        jQuery('nav .nav').mouseleave(function() {
        jQuery('.pointer').stop(true,false);
        jQuery('.pointer').animate({left: originalLeft}, 700,'easeOutCubic');
        });*/
        //sticky menu
        /*jQuery(function() {
        var menuOffset = jQuery('.navigation')[0].offsetTop;
        jQuery(document).bind('ready scroll', function() {
        var docScroll = jQuery(document).scrollTop();
        if(docScroll >= menuOffset) {
        jQuery('.navigation').addClass('nav-sticky').css('width','100%');
        jQuery('.navigation').parent().next().css('margin-top', jQuery('.navigation').height());
        } else {
        jQuery('.navigation').removeClass('nav-sticky').removeAttr('width');
        jQuery('.navigation').parent().next().css('margin-top','0');
        }
        });
        });*/
      });

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlcyI6WyJhcHBsaWNhdGlvbi5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvL2FsZXJ0KFwibG9hZGVkIG9rXCIpO1xuLy8gJCgnLmRyb3Bkb3duLXRvZ2dsZScpLmRyb3Bkb3duKClcbiQoJy5jb2xsYXBzZScpLmNvbGxhcHNlKCdzaG93JylcbiQoJyNteU1vZGFsJykubW9kYWwoJ2hpZGUnKVxuLy8kKCcudHlwZWFoZWFkJykudHlwZWFoZWFkKClcbiQoJy50YWJzJykuYnV0dG9uKClcbiQoJy50aXAnKS50b29sdGlwKClcbiQoXCIuYWxlcnQtbWVzc2FnZVwiKS5hbGVydCgpXG52YXIgIG1lbnVfb3Blbj1mYWxzZTtcblxuXG5cbmZ1bmN0aW9uIG9uQ2xpY2tNZW51KCkge1xuICAgICAgICAvL2lmIChwYXJzZUludChqUXVlcnkoJy5ib2R5JykuY3NzKCdsZWZ0JykpID49IDgwKSB7XG4gIGlmKG1lbnVfb3Blbj09ZmFsc2Upe1xuICAgICAgICAgIG9wZW5NZW51KCk7XG4gICAgICAgIH1lbHNle1xuICAgICAgICAgIGNsb3NlTWVudSgpO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIG9uQ2xpY2tDb3ZlcigpIHtcbiAgICAgICAgY2xvc2VNZW51KCk7XG4gICAgICB9XG4gICAgICB2YXIgc2Nyb2xsUG9zO1xuXG4gICAgICBmdW5jdGlvbiBvcGVuTWVudSgpIHtcbiAgICAgICAgc2Nyb2xsUG9zID0galF1ZXJ5KCdib2R5Jykuc2Nyb2xsVG9wKCk7XG4gICAgICAgIGpRdWVyeSgnLndyYXBwZXInKS5hbmltYXRlKHtcbiAgICAgICAgICBsZWZ0OiAnODAlJ1xuICAgICAgICB9KTtcbiAgICAgICAgalF1ZXJ5KCcubW9iaWxlLW1lbnUtYmFyJykuYW5pbWF0ZSh7XG4gICAgICAgICAgbGVmdDogJzgwJSdcbiAgICAgICAgfSk7XG4gICAgICAgIGpRdWVyeSgnLm9mZi1zY3JlZW4tbGVmdCcpLmNzcygnZGlzcGxheScsICdibG9jaycpO1xuICAgICAgICBqUXVlcnkoJ2JvZHknKS5jc3Moe1xuICAgICAgICAgIHBvc2l0aW9uOiAnZml4ZWQnLFxuICAgICAgICAgIHRvcDogLShkb2N1bWVudC5ib2R5LnNjcm9sbFRvcClcbiAgICAgICAgfSk7XG4gICAgICAgIGpRdWVyeSgnaHRtbCcpLmNzcyh7XG4gICAgICAgICAgcG9zaXRpb246ICdmaXhlZCcsXG4gICAgICAgICAgdG9wOiAtKGRvY3VtZW50LmJvZHkuc2Nyb2xsVG9wKVxuICAgICAgICB9KTtcbiAgICAgICAgalF1ZXJ5KFwiLmJvZHlcIikub24oXCJ0b3VjaG1vdmVcIiwgZmFsc2UpO1xuICAgICAgICBqUXVlcnkoJy5jb3ZlcicpLmZhZGVJbigpO1xuICAgICAgICAgIG1lbnVfb3Blbj10cnVlO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiBjbG9zZU1lbnUoKSB7XG4gICAgICAgIGpRdWVyeSgnLndyYXBwZXInKS5hbmltYXRlKHtcbiAgICAgICAgICBsZWZ0OiAnMCUnXG4gICAgICAgIH0pO1xuICAgICAgICBqUXVlcnkoJy5tb2JpbGUtbWVudS1iYXInKS5hbmltYXRlKHtcbiAgICAgICAgICBsZWZ0OiAnMCUnXG4gICAgICAgIH0sIGZ1bmN0aW9uKCkge1xuICAgICAgICAgIGpRdWVyeSgnLm9mZi1zY3JlZW4tbGVmdCcpLmNzcygnZGlzcGxheScsICdub25lJyk7XG4gICAgICAgIH0pO1xuICAgICAgICBqUXVlcnkoJ2JvZHknKS5jc3Moe1xuICAgICAgICAgIHBvc2l0aW9uOiAnaW5oZXJpdCdcbiAgICAgICAgfSk7XG4gICAgICAgIGpRdWVyeSgnaHRtbCcpLmNzcyh7XG4gICAgICAgICAgcG9zaXRpb246ICdpbmhlcml0J1xuICAgICAgICB9KTtcbiAgICAgICAgalF1ZXJ5KCdib2R5Jykuc2Nyb2xsVG9wKHNjcm9sbFBvcyk7XG4gICAgICAgIGpRdWVyeShcIi5ib2R5XCIpLm9mZihcInRvdWNobW92ZVwiLCBmYWxzZSk7XG4gICAgICAgIGpRdWVyeSgnLmNvdmVyJykuZmFkZU91dCgpO1xuICAgICAgICAgICBtZW51X29wZW49ZmFsc2U7XG4gICAgICB9XG4gICAgICBqUXVlcnkoZG9jdW1lbnQpLnJlYWR5KGZ1bmN0aW9uKCkge1xuICAgICAgICAvL2luaXQgcGFycmFsYXhcbiAgICAgICAgLy92YXIgc2tyID0gc2tyb2xsci5pbml0KCk7XG4gICAgICAgIC8vYW5pbWF0ZSBwb2ludGVyXG4gICAgICAgIC8qdmFyIE9GRlNFVF9DT05TVCA9IDMwO1xuICAgICAgICB2YXIgb3JpZ2luYWxMZWZ0ID0galF1ZXJ5KCduYXYgdWwgLmN1cnJlbnQnKS5wb3NpdGlvbigpLmxlZnQgKyBPRkZTRVRfQ09OU1Q7XG4gICAgICAgIGpRdWVyeSgnLnBvaW50ZXInKS5hbmltYXRlKHtsZWZ0OiBvcmlnaW5hbExlZnR9LCA1MDAsJ2Vhc2VPdXRDdWJpYycpO1xuICAgICAgICBqUXVlcnkoJ25hdiAubmF2IGxpJykubW91c2VvdmVyKGZ1bmN0aW9uKCkge1xuICAgICAgICAvL3N0b3AgY3VycmVudCBhbmltYXRpb25cbiAgICAgICAgalF1ZXJ5KCcucG9pbnRlcicpLnN0b3AodHJ1ZSxmYWxzZSk7XG4gICAgICAgIHZhciBsZWZ0ID0galF1ZXJ5KHRoaXMpLnBvc2l0aW9uKCkubGVmdCArIE9GRlNFVF9DT05TVDtcbiAgICAgICAgalF1ZXJ5KCcucG9pbnRlcicpLmFuaW1hdGUoe2xlZnQ6IGxlZnR9LCA1MDAsJ2Vhc2VPdXRDdWJpYycpO1xuICAgICAgICB9KTtcbiAgICAgICAgalF1ZXJ5KCduYXYgLm5hdicpLm1vdXNlbGVhdmUoZnVuY3Rpb24oKSB7XG4gICAgICAgIGpRdWVyeSgnLnBvaW50ZXInKS5zdG9wKHRydWUsZmFsc2UpO1xuICAgICAgICBqUXVlcnkoJy5wb2ludGVyJykuYW5pbWF0ZSh7bGVmdDogb3JpZ2luYWxMZWZ0fSwgNzAwLCdlYXNlT3V0Q3ViaWMnKTtcbiAgICAgICAgfSk7Ki9cbiAgICAgICAgLy9zdGlja3kgbWVudVxuICAgICAgICAvKmpRdWVyeShmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIG1lbnVPZmZzZXQgPSBqUXVlcnkoJy5uYXZpZ2F0aW9uJylbMF0ub2Zmc2V0VG9wO1xuICAgICAgICBqUXVlcnkoZG9jdW1lbnQpLmJpbmQoJ3JlYWR5IHNjcm9sbCcsIGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgZG9jU2Nyb2xsID0galF1ZXJ5KGRvY3VtZW50KS5zY3JvbGxUb3AoKTtcbiAgICAgICAgaWYoZG9jU2Nyb2xsID49IG1lbnVPZmZzZXQpIHtcbiAgICAgICAgalF1ZXJ5KCcubmF2aWdhdGlvbicpLmFkZENsYXNzKCduYXYtc3RpY2t5JykuY3NzKCd3aWR0aCcsJzEwMCUnKTtcbiAgICAgICAgalF1ZXJ5KCcubmF2aWdhdGlvbicpLnBhcmVudCgpLm5leHQoKS5jc3MoJ21hcmdpbi10b3AnLCBqUXVlcnkoJy5uYXZpZ2F0aW9uJykuaGVpZ2h0KCkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICBqUXVlcnkoJy5uYXZpZ2F0aW9uJykucmVtb3ZlQ2xhc3MoJ25hdi1zdGlja3knKS5yZW1vdmVBdHRyKCd3aWR0aCcpO1xuICAgICAgICBqUXVlcnkoJy5uYXZpZ2F0aW9uJykucGFyZW50KCkubmV4dCgpLmNzcygnbWFyZ2luLXRvcCcsJzAnKTtcbiAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgfSk7Ki9cbiAgICAgIH0pO1xuIl0sImZpbGUiOiJhcHBsaWNhdGlvbi5qcyJ9
