// Add classes

window.onload=function() {
var input = document.getElementsByTagName("input");
for (var i = 0; i < input.length; i++) {
    if (input[i].className == 'button') {
        input[i].className = 'btn btn-primary';
    }
}

var button = document.getElementsByTagName("button");
for (var i = 0; i < input.length; i++) {
    if (button[i].className == 'button') {
        button[i].className = 'btn btn-primary';
    }
}

var p = document.getElementsByTagName("p");
for (var i = 0; i < p.length; i++) {
    if (p[i].className == 'readmore') {
        p[i].className = 'btn';
    }
}

var table = document.getElementsByTagName("table");
for (var i = 0; i < table.length; i++) {
    if (table[i].className == 'category') {
        table[i].className = 'table table-striped';
    }
}

var ul = document.getElementsByTagName("ul");
for (var i = 0; i < ul.length; i++) {
    if (ul[i].className == 'actions') {
        ul[i].className = 'nav nav-pills';
    }
}

var ul = document.getElementsByTagName("ul");
for (var i = 0; i < ul.length; i++) {
    if (ul[i].className == 'pagenav') {
        ul[i].className = 'pagination';
    }
}
}
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlcyI6WyJjbGFzc2VzLmpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIEFkZCBjbGFzc2VzXG5cbndpbmRvdy5vbmxvYWQ9ZnVuY3Rpb24oKSB7XG52YXIgaW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZShcImlucHV0XCIpO1xuZm9yICh2YXIgaSA9IDA7IGkgPCBpbnB1dC5sZW5ndGg7IGkrKykge1xuICAgIGlmIChpbnB1dFtpXS5jbGFzc05hbWUgPT0gJ2J1dHRvbicpIHtcbiAgICAgICAgaW5wdXRbaV0uY2xhc3NOYW1lID0gJ2J0biBidG4tcHJpbWFyeSc7XG4gICAgfVxufVxuXG52YXIgYnV0dG9uID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJidXR0b25cIik7XG5mb3IgKHZhciBpID0gMDsgaSA8IGlucHV0Lmxlbmd0aDsgaSsrKSB7XG4gICAgaWYgKGJ1dHRvbltpXS5jbGFzc05hbWUgPT0gJ2J1dHRvbicpIHtcbiAgICAgICAgYnV0dG9uW2ldLmNsYXNzTmFtZSA9ICdidG4gYnRuLXByaW1hcnknO1xuICAgIH1cbn1cblxudmFyIHAgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZShcInBcIik7XG5mb3IgKHZhciBpID0gMDsgaSA8IHAubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAocFtpXS5jbGFzc05hbWUgPT0gJ3JlYWRtb3JlJykge1xuICAgICAgICBwW2ldLmNsYXNzTmFtZSA9ICdidG4nO1xuICAgIH1cbn1cblxudmFyIHRhYmxlID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJ0YWJsZVwiKTtcbmZvciAodmFyIGkgPSAwOyBpIDwgdGFibGUubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAodGFibGVbaV0uY2xhc3NOYW1lID09ICdjYXRlZ29yeScpIHtcbiAgICAgICAgdGFibGVbaV0uY2xhc3NOYW1lID0gJ3RhYmxlIHRhYmxlLXN0cmlwZWQnO1xuICAgIH1cbn1cblxudmFyIHVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJ1bFwiKTtcbmZvciAodmFyIGkgPSAwOyBpIDwgdWwubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAodWxbaV0uY2xhc3NOYW1lID09ICdhY3Rpb25zJykge1xuICAgICAgICB1bFtpXS5jbGFzc05hbWUgPSAnbmF2IG5hdi1waWxscyc7XG4gICAgfVxufVxuXG52YXIgdWwgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZShcInVsXCIpO1xuZm9yICh2YXIgaSA9IDA7IGkgPCB1bC5sZW5ndGg7IGkrKykge1xuICAgIGlmICh1bFtpXS5jbGFzc05hbWUgPT0gJ3BhZ2VuYXYnKSB7XG4gICAgICAgIHVsW2ldLmNsYXNzTmFtZSA9ICdwYWdpbmF0aW9uJztcbiAgICB9XG59XG59Il0sImZpbGUiOiJjbGFzc2VzLmpzIn0=
