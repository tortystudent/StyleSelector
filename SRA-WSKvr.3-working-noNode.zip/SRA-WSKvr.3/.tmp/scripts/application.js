//alert("loaded ok");
console.log("!!!!!!!!!!APPLICATION!!!!!!!!!!!!!");
// $('.dropdown-toggle').dropdown()
$('.collapse').collapse('show')
$('#myModal').modal('hide')
//$('.typeahead').typeahead()
$('.tabs').button()
$('.tip').tooltip()
$(".alert-message").alert()




function onClickMenu() {
        if (parseInt(jQuery('.body').css('left')) >= 80) {
          closeMenu()
        } else {
          openMenu();
        }
      }

      function onClickCover() {
        closeMenu();
      }
      var scrollPos;

      function openMenu() {
        scrollPos = jQuery('body').scrollTop();
        jQuery('.wrapper').animate({
          left: '80%'
        });
        jQuery('.mobile-menu-bar').animate({
          left: '80%'
        });
        jQuery('.off-screen-left').css('display', 'block');
        jQuery('body').css({
          position: 'fixed',
          top: -(document.body.scrollTop)
        });
        jQuery('html').css({
          position: 'fixed',
          top: -(document.body.scrollTop)
        });
        jQuery(".body").on("touchmove", false);
        jQuery('.cover').fadeIn();
      }

      function closeMenu() {
        jQuery('.wrapper').animate({
          left: '0%'
        });
        jQuery('.mobile-menu-bar').animate({
          left: '0%'
        }, function() {
          jQuery('.off-screen-left').css('display', 'none');
        });
        jQuery('body').css({
          position: 'inherit'
        });
        jQuery('html').css({
          position: 'inherit'
        });
        jQuery('body').scrollTop(scrollPos);
        jQuery(".body").off("touchmove", false);
        jQuery('.cover').fadeOut();
      }
      jQuery(document).ready(function() {
        //init parralax
        //var skr = skrollr.init();
        //animate pointer
        /*var OFFSET_CONST = 30;
        var originalLeft = jQuery('nav ul .current').position().left + OFFSET_CONST;
        jQuery('.pointer').animate({left: originalLeft}, 500,'easeOutCubic');
        jQuery('nav .nav li').mouseover(function() {
        //stop current animation
        jQuery('.pointer').stop(true,false);
        var left = jQuery(this).position().left + OFFSET_CONST;
        jQuery('.pointer').animate({left: left}, 500,'easeOutCubic');
        });
        jQuery('nav .nav').mouseleave(function() {
        jQuery('.pointer').stop(true,false);
        jQuery('.pointer').animate({left: originalLeft}, 700,'easeOutCubic');
        });*/
        //sticky menu
        /*jQuery(function() {
        var menuOffset = jQuery('.navigation')[0].offsetTop;
        jQuery(document).bind('ready scroll', function() {
        var docScroll = jQuery(document).scrollTop();
        if(docScroll >= menuOffset) {
        jQuery('.navigation').addClass('nav-sticky').css('width','100%');
        jQuery('.navigation').parent().next().css('margin-top', jQuery('.navigation').height());
        } else {
        jQuery('.navigation').removeClass('nav-sticky').removeAttr('width');
        jQuery('.navigation').parent().next().css('margin-top','0');
        }
        });
        });*/
      });








console.log("!!!!!!!!!!APPLICATION!!!!!!!!!!!!!");
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlcyI6WyJhcHBsaWNhdGlvbi5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvL2FsZXJ0KFwibG9hZGVkIG9rXCIpO1xuY29uc29sZS5sb2coXCIhISEhISEhISEhQVBQTElDQVRJT04hISEhISEhISEhISEhXCIpO1xuLy8gJCgnLmRyb3Bkb3duLXRvZ2dsZScpLmRyb3Bkb3duKClcbiQoJy5jb2xsYXBzZScpLmNvbGxhcHNlKCdzaG93JylcbiQoJyNteU1vZGFsJykubW9kYWwoJ2hpZGUnKVxuLy8kKCcudHlwZWFoZWFkJykudHlwZWFoZWFkKClcbiQoJy50YWJzJykuYnV0dG9uKClcbiQoJy50aXAnKS50b29sdGlwKClcbiQoXCIuYWxlcnQtbWVzc2FnZVwiKS5hbGVydCgpXG5cblxuXG5cbmZ1bmN0aW9uIG9uQ2xpY2tNZW51KCkge1xuICAgICAgICBpZiAocGFyc2VJbnQoalF1ZXJ5KCcuYm9keScpLmNzcygnbGVmdCcpKSA+PSA4MCkge1xuICAgICAgICAgIGNsb3NlTWVudSgpXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgb3Blbk1lbnUoKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiBvbkNsaWNrQ292ZXIoKSB7XG4gICAgICAgIGNsb3NlTWVudSgpO1xuICAgICAgfVxuICAgICAgdmFyIHNjcm9sbFBvcztcblxuICAgICAgZnVuY3Rpb24gb3Blbk1lbnUoKSB7XG4gICAgICAgIHNjcm9sbFBvcyA9IGpRdWVyeSgnYm9keScpLnNjcm9sbFRvcCgpO1xuICAgICAgICBqUXVlcnkoJy53cmFwcGVyJykuYW5pbWF0ZSh7XG4gICAgICAgICAgbGVmdDogJzgwJSdcbiAgICAgICAgfSk7XG4gICAgICAgIGpRdWVyeSgnLm1vYmlsZS1tZW51LWJhcicpLmFuaW1hdGUoe1xuICAgICAgICAgIGxlZnQ6ICc4MCUnXG4gICAgICAgIH0pO1xuICAgICAgICBqUXVlcnkoJy5vZmYtc2NyZWVuLWxlZnQnKS5jc3MoJ2Rpc3BsYXknLCAnYmxvY2snKTtcbiAgICAgICAgalF1ZXJ5KCdib2R5JykuY3NzKHtcbiAgICAgICAgICBwb3NpdGlvbjogJ2ZpeGVkJyxcbiAgICAgICAgICB0b3A6IC0oZG9jdW1lbnQuYm9keS5zY3JvbGxUb3ApXG4gICAgICAgIH0pO1xuICAgICAgICBqUXVlcnkoJ2h0bWwnKS5jc3Moe1xuICAgICAgICAgIHBvc2l0aW9uOiAnZml4ZWQnLFxuICAgICAgICAgIHRvcDogLShkb2N1bWVudC5ib2R5LnNjcm9sbFRvcClcbiAgICAgICAgfSk7XG4gICAgICAgIGpRdWVyeShcIi5ib2R5XCIpLm9uKFwidG91Y2htb3ZlXCIsIGZhbHNlKTtcbiAgICAgICAgalF1ZXJ5KCcuY292ZXInKS5mYWRlSW4oKTtcbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gY2xvc2VNZW51KCkge1xuICAgICAgICBqUXVlcnkoJy53cmFwcGVyJykuYW5pbWF0ZSh7XG4gICAgICAgICAgbGVmdDogJzAlJ1xuICAgICAgICB9KTtcbiAgICAgICAgalF1ZXJ5KCcubW9iaWxlLW1lbnUtYmFyJykuYW5pbWF0ZSh7XG4gICAgICAgICAgbGVmdDogJzAlJ1xuICAgICAgICB9LCBmdW5jdGlvbigpIHtcbiAgICAgICAgICBqUXVlcnkoJy5vZmYtc2NyZWVuLWxlZnQnKS5jc3MoJ2Rpc3BsYXknLCAnbm9uZScpO1xuICAgICAgICB9KTtcbiAgICAgICAgalF1ZXJ5KCdib2R5JykuY3NzKHtcbiAgICAgICAgICBwb3NpdGlvbjogJ2luaGVyaXQnXG4gICAgICAgIH0pO1xuICAgICAgICBqUXVlcnkoJ2h0bWwnKS5jc3Moe1xuICAgICAgICAgIHBvc2l0aW9uOiAnaW5oZXJpdCdcbiAgICAgICAgfSk7XG4gICAgICAgIGpRdWVyeSgnYm9keScpLnNjcm9sbFRvcChzY3JvbGxQb3MpO1xuICAgICAgICBqUXVlcnkoXCIuYm9keVwiKS5vZmYoXCJ0b3VjaG1vdmVcIiwgZmFsc2UpO1xuICAgICAgICBqUXVlcnkoJy5jb3ZlcicpLmZhZGVPdXQoKTtcbiAgICAgIH1cbiAgICAgIGpRdWVyeShkb2N1bWVudCkucmVhZHkoZnVuY3Rpb24oKSB7XG4gICAgICAgIC8vaW5pdCBwYXJyYWxheFxuICAgICAgICAvL3ZhciBza3IgPSBza3JvbGxyLmluaXQoKTtcbiAgICAgICAgLy9hbmltYXRlIHBvaW50ZXJcbiAgICAgICAgLyp2YXIgT0ZGU0VUX0NPTlNUID0gMzA7XG4gICAgICAgIHZhciBvcmlnaW5hbExlZnQgPSBqUXVlcnkoJ25hdiB1bCAuY3VycmVudCcpLnBvc2l0aW9uKCkubGVmdCArIE9GRlNFVF9DT05TVDtcbiAgICAgICAgalF1ZXJ5KCcucG9pbnRlcicpLmFuaW1hdGUoe2xlZnQ6IG9yaWdpbmFsTGVmdH0sIDUwMCwnZWFzZU91dEN1YmljJyk7XG4gICAgICAgIGpRdWVyeSgnbmF2IC5uYXYgbGknKS5tb3VzZW92ZXIoZnVuY3Rpb24oKSB7XG4gICAgICAgIC8vc3RvcCBjdXJyZW50IGFuaW1hdGlvblxuICAgICAgICBqUXVlcnkoJy5wb2ludGVyJykuc3RvcCh0cnVlLGZhbHNlKTtcbiAgICAgICAgdmFyIGxlZnQgPSBqUXVlcnkodGhpcykucG9zaXRpb24oKS5sZWZ0ICsgT0ZGU0VUX0NPTlNUO1xuICAgICAgICBqUXVlcnkoJy5wb2ludGVyJykuYW5pbWF0ZSh7bGVmdDogbGVmdH0sIDUwMCwnZWFzZU91dEN1YmljJyk7XG4gICAgICAgIH0pO1xuICAgICAgICBqUXVlcnkoJ25hdiAubmF2JykubW91c2VsZWF2ZShmdW5jdGlvbigpIHtcbiAgICAgICAgalF1ZXJ5KCcucG9pbnRlcicpLnN0b3AodHJ1ZSxmYWxzZSk7XG4gICAgICAgIGpRdWVyeSgnLnBvaW50ZXInKS5hbmltYXRlKHtsZWZ0OiBvcmlnaW5hbExlZnR9LCA3MDAsJ2Vhc2VPdXRDdWJpYycpO1xuICAgICAgICB9KTsqL1xuICAgICAgICAvL3N0aWNreSBtZW51XG4gICAgICAgIC8qalF1ZXJ5KGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgbWVudU9mZnNldCA9IGpRdWVyeSgnLm5hdmlnYXRpb24nKVswXS5vZmZzZXRUb3A7XG4gICAgICAgIGpRdWVyeShkb2N1bWVudCkuYmluZCgncmVhZHkgc2Nyb2xsJywgZnVuY3Rpb24oKSB7XG4gICAgICAgIHZhciBkb2NTY3JvbGwgPSBqUXVlcnkoZG9jdW1lbnQpLnNjcm9sbFRvcCgpO1xuICAgICAgICBpZihkb2NTY3JvbGwgPj0gbWVudU9mZnNldCkge1xuICAgICAgICBqUXVlcnkoJy5uYXZpZ2F0aW9uJykuYWRkQ2xhc3MoJ25hdi1zdGlja3knKS5jc3MoJ3dpZHRoJywnMTAwJScpO1xuICAgICAgICBqUXVlcnkoJy5uYXZpZ2F0aW9uJykucGFyZW50KCkubmV4dCgpLmNzcygnbWFyZ2luLXRvcCcsIGpRdWVyeSgnLm5hdmlnYXRpb24nKS5oZWlnaHQoKSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgIGpRdWVyeSgnLm5hdmlnYXRpb24nKS5yZW1vdmVDbGFzcygnbmF2LXN0aWNreScpLnJlbW92ZUF0dHIoJ3dpZHRoJyk7XG4gICAgICAgIGpRdWVyeSgnLm5hdmlnYXRpb24nKS5wYXJlbnQoKS5uZXh0KCkuY3NzKCdtYXJnaW4tdG9wJywnMCcpO1xuICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICB9KTsqL1xuICAgICAgfSk7XG5cblxuXG5cblxuXG5cblxuY29uc29sZS5sb2coXCIhISEhISEhISEhQVBQTElDQVRJT04hISEhISEhISEhISEhXCIpOyJdLCJmaWxlIjoiYXBwbGljYXRpb24uanMifQ==
